﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title></title>
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="stylesheet" href="css/InformDetail.css" media="screen" type="text/css" />
</head>

<body>
	
	<div class="container">

		<div class="middle">
		
			<div class="title">
				<span style="font-size:25px; height:35px;">通知标题</span>
				<span style="font-size:14px; height:15px;">发布人</span>
			</div>
			<div class="content" style="text-align:center; font:20px;">
			内容......
			</div>
			<div class="time">
			2016/03/24
			</div>
		
		</div>
		
	</div>
	
</body>

</html>