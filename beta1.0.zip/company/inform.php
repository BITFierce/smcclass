﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title></title>
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="stylesheet" href="css/inform.css" media="screen" type="text/css" />
</head>
	
<body>

	<div class="container">
	
		<div class="head">
			<div></div>
			<span>通知列表</span>
		</div>
		
		<div class="type">
			<span>当前通知</span>
		</div>
		
		<div class="title">
			<span>序号</span>
			<span style="width:300px;">通知标题</span>
			<span>类型</span>
			<span style="width:100px;">发布时间</span>
		</div>
		
		<div class="content">
			<div class="cstyle">
				<span>1</span>
				<span style="width:300px;"><a href="InformDetail.php" target="_blank">标题</a></span>
				<span>省</span>
				<span>2016/03/24</span>
			</div>
			<div class="cstyle">
				<span>2</span>
				<span style="width:300px;"><a href="InformDetail.php" target="_blank">标题</a></span>
				<span>省</span>
				<span style="width:100px;">2016/03/24</span>
			</div>
		</div>
	
	</div>

</body>

</html>