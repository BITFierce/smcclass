﻿<?php
	$username=$_GET['username'];
	$userpassword=$_GET['userpassword'];
	$usertype=$_GET['usertype'];
	//连接数据库
	include '../sql/sqlname.php';
	$connect=mysql_connect($sql_host,$sql_user,$sql_pass) or die('Could not connect: ' . mysql_error());
	mysql_select_db($sql_name, $connect);
	mysql_query("set names 'utf8'",$connect);
	$sql="delete from `user` where UserName = '".$username."';";
	$result = mysql_query($sql,$connect);
	$sql="insert into `user` (UserName, UserPassword, UserType) values('".$username."', '".$userpassword."', '".$usertype."');";
	$result = mysql_query($sql,$connect);
	if($result=='true')
		echo "true";
	else
		echo "false";
	mysql_close($connect);
?>